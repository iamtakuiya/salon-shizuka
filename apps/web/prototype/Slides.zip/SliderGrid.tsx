/**
 * SliderGrid
 * ──────────
 * Renders one slide's worth of items in one of two layouts:
 *
 *  "uniform"  — equal-width columns, all same aspect-ratio.
 *               Used by: StyleGuideTeaser
 *
 *  "varied"   — 4-col grid where items can span 1 or 2 columns.
 *               Used by: GallerySlider
 *
 * Each item carries a `data-slider-item` attribute so the parent
 * <ImageSlider> can target them for GSAP stagger animations.
 *
 * This component owns:
 *  - grid layout
 *  - image placeholder (swap for <img> once assets are ready)
 *  - overlay label on hover
 *  - item caption below image
 *
 * This component does NOT own:
 *  - slider state, navigation, dots, or arrows  →  <ImageSlider>
 *  - section padding, headings, or background   →  section component
 */

import type { SliderItem } from '../ImageSlider/ImageSlider';
import styles from './SliderGrid.module.scss';

// ── Types ───────────────────────────────────────────────────────────────────

export type GridVariant = 'uniform' | 'varied';

export interface SliderGridProps {
  items: SliderItem[];
  variant?: GridVariant;
  /** aspect-ratio for each image cell — CSS string e.g. "3/4" or "1/1" */
  aspectRatio?: string;
}

// ── Component ───────────────────────────────────────────────────────────────

export function SliderGrid({
  items,
  variant = 'uniform',
  aspectRatio = '3 / 4',
}: SliderGridProps) {
  return (
    <div
      className={`${styles.sliderGrid} ${styles[`sliderGrid--${variant}`]}`}
    >
      {items.map((item) => {
        const isWide = variant === 'varied' && item.span === 2;

        return (
          <div
            key={item.id}
            data-slider-item          // GSAP stagger target
            className={`${styles.sliderGrid__item} ${isWide ? styles['sliderGrid__item--wide'] : ''}`}
          >
            {/* Image — placeholder until real src available */}
            <div
              className={styles.sliderGrid__imgWrap}
              style={{ '--aspect': aspectRatio } as React.CSSProperties}
            >
              {item.src ? (
                <img
                  src={item.src}
                  alt={item.alt}
                  className={styles.sliderGrid__img}
                />
              ) : (
                <div
                  className={styles.sliderGrid__placeholder}
                  role="img"
                  aria-label={item.alt}
                  style={{ '--tint': item.tint ?? 'var(--color-accent)' } as React.CSSProperties}
                />
              )}

              {/* Hover overlay with English label */}
              {item.label && (
                <div className={styles.sliderGrid__overlay} aria-hidden="true">
                  <span className={styles.sliderGrid__overlayLabel}>
                    {item.label}
                  </span>
                </div>
              )}
            </div>

            {/* Caption below image — shown in uniform mode */}
            {(item.label || item.labelJa) && (
              <div className={styles.sliderGrid__caption}>
                {item.label   && <span className={styles.sliderGrid__captionEn}>{item.label}</span>}
                {item.labelJa && <span className={styles.sliderGrid__captionJa}>{item.labelJa}</span>}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
