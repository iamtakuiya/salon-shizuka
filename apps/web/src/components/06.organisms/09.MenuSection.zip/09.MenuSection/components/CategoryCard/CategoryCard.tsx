import type { MenuCategory, MenuItem } from '@/utils/constants';
import styles from './CategoryCard.module.scss';
import { MenuList } from '../MenuList/MenuList';



// ─── CategoryCard ─────────────────────────────────────────────────────────────
// Defined outside MenuSection so React never unmounts/remounts it on re-render.
interface CategoryCardProps {
  category: MenuCategory;
  /** Index within the full MENU_CATEGORIES array — drives CSS stagger */
  globalIndex: number;
}

export function CategoryCard({ category, globalIndex }: CategoryCardProps) {
  return (
    <article
      className={styles.menu__category}
      style={{ '--cat-index': globalIndex } as React.CSSProperties}
    >
      {/* Category header */}
      <header className={styles.menu__categoryHeader}>
        <div className={styles.menu__categoryTitle}>
          <h3 className={styles.menu__categoryName}>{category.category}</h3>
          {category.includes && (
            <span className={styles.menu__categoryIncludes}>
              ［{category.includes}］
            </span>
          )}
        </div>
        {category.categoryDescription && (
          <p className={styles.menu__categoryDesc}>
            {category.categoryDescription}
          </p>
        )}
      </header>

      {/* List */}
      {/* <div className={styles.menu__itemList}>
        {category.items.map((item, itemIdx) => (
          <div
            key={`${category.id}-item-${itemIdx}`}
            className={styles.menu__row}
            style={{ '--row-index': itemIdx } as React.CSSProperties}
          >
            <div className={styles.menu__rowLeft}>
              <span className={styles.menu__rowName}>{item.name}</span>
              {item.includes && (
                <span className={styles.menu__rowIncludes}>
                  [{item.includes}]
                </span>
              )}
              {item.description && (
                <span className={styles.menu__rowDesc}>{item.description}</span>
              )}
            </div>
            <div className={styles.menu__rowRight}>
              {item.duration && (
                <span className={styles.menu__rowDuration}>{item.duration}</span>
              )}
              <data className={styles.menu__rowPrice}>{formatPrice(item)}</data>
            </div>
          </div>
        ))}
      </div> */}
      <MenuList category={category} />

      {/* Optional notes box */}
      {category.notes && (
        <div className={styles.menu__categoryNote}>
          <p>＊{category.notes}</p>
        </div>
      )}
    </article>
  );
}