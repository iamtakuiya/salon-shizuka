/**
 * GallerySlider
 * ─────────────
 * Salon gallery section. Uses <ImageSlider> + <SliderGrid variant="varied">
 * for mixed-span images.
 *
 * Layout:
 *  ┌────────────────────────────────────────┐
 *  │  sub-label + heading      [ ← ] [ → ] │  ← header row
 *  │  ┌──────────────────────────────────┐  │
 *  │  │  mixed-size image grid           │  │  ← viewport (overflow: hidden)
 *  │  └──────────────────────────────────┘  │
 *  │           ●  ○  ○  ○  ○  ○            │  ← dots
 *  └────────────────────────────────────────┘
 */

import styles from './GallerySlider.module.scss';
import { Section }      from '@/components/primitives/Section/Section';
import { Container }    from '@/components/primitives/Container/Container';
import { Stack }        from '@/components/primitives/Stack/Stack';
import { ImageSlider }  from '@/components/molecules/ImageSlider/ImageSlider';
import { SliderGrid }   from '@/components/molecules/SliderGrid/SliderGrid';
import { useScrollReveal } from '@/animations/hooks/useScrollReveal';
import type { SliderPage } from '@/components/molecules/ImageSlider/ImageSlider';

// ── Data ────────────────────────────────────────────────────────────────────
// Each page = one visible slide. span: 2 = double-wide column.
const TINTS = [
  '#D9BF97','#C9A96E','#BF9A5A','#E8D7BF',
  '#D4C4A8','#C5AD80','#BAA070','#DBCBAd',
  '#C9A96E','#D9BF97','#BF9A5A','#E8D7BF',
  '#D4C4A8','#C5AD80','#BF9A5A','#E8D7BF',
  '#C9A96E','#D9BF97',
];

const SLIDES: SliderPage[] = [
  [
    { id:  1, alt: 'ナチュラルカラー',  label: 'Natural Color', span: 1, tint: TINTS[0] },
    { id:  2, alt: 'ボブスタイル',       label: 'Bob Style',     span: 2, tint: TINTS[1] },
    { id:  3, alt: 'ハイライト',         label: 'Highlight',     span: 1, tint: TINTS[2] },
  ],
  [
    { id:  4, alt: 'パーマスタイル',     label: 'Perm Style',    span: 2, tint: TINTS[3] },
    { id:  5, alt: 'トリートメント',     label: 'Treatment',     span: 1, tint: TINTS[4] },
    { id:  6, alt: 'ロングスタイル',     label: 'Long Style',    span: 1, tint: TINTS[5] },
  ],
  [
    { id:  7, alt: 'インナーカラー',     label: 'Inner Color',   span: 1, tint: TINTS[6] },
    { id:  8, alt: 'ショートカット',     label: 'Short Cut',     span: 1, tint: TINTS[7] },
    { id:  9, alt: 'ウェーブパーマ',     label: 'Wave Perm',     span: 2, tint: TINTS[8] },
  ],
  [
    { id: 10, alt: 'アッシュカラー',     label: 'Ash Color',     span: 2, tint: TINTS[9] },
    { id: 11, alt: 'ヘッドスパ',         label: 'Head Spa',      span: 1, tint: TINTS[10] },
    { id: 12, alt: 'グラデーション',     label: 'Gradation',     span: 1, tint: TINTS[11] },
  ],
  [
    { id: 13, alt: 'ミルクティーカラー', label: 'Milk Tea',      span: 1, tint: TINTS[12] },
    { id: 14, alt: 'レイヤードカット',   label: 'Layered Cut',   span: 2, tint: TINTS[13] },
    { id: 15, alt: 'バレイヤージュ',     label: 'Balayage',      span: 1, tint: TINTS[14] },
  ],
  [
    { id: 16, alt: 'ナチュラルパーマ',   label: 'Natural Perm',  span: 1, tint: TINTS[15] },
    { id: 17, alt: 'トーンアップ',       label: 'Tone-Up',       span: 1, tint: TINTS[16] },
    { id: 18, alt: 'リラクゼーション',   label: 'Relaxation',    span: 2, tint: TINTS[17] },
  ],
];

// ── Component ───────────────────────────────────────────────────────────────

export default function GallerySlider() {
  const labelRef   = useScrollReveal<HTMLSpanElement>();
  const headingRef = useScrollReveal<HTMLHeadingElement>();

  return (
    <Section id="gallery" spacing="lg" aria-label="Gallery">
      <Container>
        <ImageSlider
          slides={SLIDES}
          renderSlide={(items) => (
            <SliderGrid items={items} variant="varied" aspectRatio="3 / 4" />
          )}
          ariaLabel="施術例ギャラリー"
        >
          {({ ArrowPrev, ArrowNext, Dots }) => (
            <>
              {/* Header: label + heading left, arrows right */}
              <div className={styles.gallery__header}>
                <Stack gap="xs">
                  <span ref={labelRef} className="section-label">
                    完全予約制・プライベートサロン SHIZUKA
                  </span>
                  <h2 ref={headingRef} className={styles.gallery__heading}>
                    Salon Gallery
                  </h2>
                </Stack>

                <div className={styles.gallery__arrows}>
                  <ArrowPrev />
                  <ArrowNext />
                </div>
              </div>

              {/* Dots centered below — rendered by ImageSlider after viewport */}
              <Dots />
            </>
          )}
        </ImageSlider>
      </Container>
    </Section>
  );
}
