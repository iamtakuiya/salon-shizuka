import type { MenuCategory, MenuItem } from '@/utils/constants';
import { formatPrice } from '@/utils/formatPrice';
import styles from './MenuItem.module.scss';

interface CategoryCardProps {
  category: MenuCategory;
}

export function MenuList({ category }:CategoryCardProps) {
  return (
    <div className={styles.menu__itemList}>
      {category.items.map((item, itemIdx) => (
        <div
          key={`${category.id}-item-${itemIdx}`}
          className={styles.menu__row}
          style={{ '--row-index': itemIdx } as React.CSSProperties}
        >
          <div className={styles.menu__rowLeft}>
            <h4 className={styles.menu__rowName}>{item.name}</h4>
            {item.includes && (
              <span className={styles.menu__rowIncludes}>
                [{item.includes}]
              </span>
            )}
            {item.description && (
              <span className={styles.menu__rowDesc}>{item.description}</span>
            )}
          </div>
          <div className={styles.menu__rowRight}>
            <data className={styles.menu__rowPrice}>{formatPrice(item)}</data>
            {item.duration && (
              <span className={styles.menu__rowDuration}>{item.duration}</span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}