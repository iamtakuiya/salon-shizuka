/**
 * ImageSlider
 * ───────────
 * Generic, reusable slider shell.
 *
 * Responsibilities:
 *  - GSAP slide transition (fade + directional x)
 *  - Arrow controls (rendered via render-prop so callers can restyle)
 *  - Dot pagination
 *  - Keyboard ← → support
 *  - Accessibility (aria-live, role="tab", aria-selected)
 *
 * NOT responsible for:
 *  - What the slides look like  →  children() render prop
 *  - Section layout (heading, text columns, backgrounds)  →  caller
 *
 * Usage
 * ─────
 *  <ImageSlider slides={SLIDES} renderSlide={(slide) => <SliderGrid ... />}>
 *    {({ ArrowPrev, ArrowNext, Dots }) => (
 *      <>
 *        <ArrowPrev />
 *        <ArrowNext />
 *        <Dots />
 *      </>
 *    )}
 *  </ImageSlider>
 *
 *  The children function receives pre-wired control components so callers
 *  can place them anywhere in their layout (top-right, bottom-center, etc.)
 *  without reimplementing the logic.
 */

import {
  useRef, useEffect, useCallback, type ReactNode,
} from 'react';
import { gsap } from 'gsap';
import { useSlider } from './useSlider';
import styles from './ImageSlider.module.scss';

// ── Types ───────────────────────────────────────────────────────────────────

export interface SliderItem {
  id: number;
  alt: string;
  label?: string;
  labelJa?: string;
  /** 1 = normal column width · 2 = double-wide (varied grid only) */
  span?: 1 | 2;
  /** Placeholder tint — remove once real images are wired */
  tint?: string;
  /** Real image src — leave undefined to render tint placeholder */
  src?: string;
}

/** One "page" of the slider — an array of items shown together */
export type SliderPage = SliderItem[];

export interface ControlComponents {
  /** Pre-wired ← button */
  ArrowPrev: () => JSX.Element;
  /** Pre-wired → button */
  ArrowNext: () => JSX.Element;
  /** Pre-wired dot row */
  Dots: () => JSX.Element;
}

export interface ImageSliderProps {
  /** Array of pages; each page is rendered as one full slide */
  slides: SliderPage[];
  /** Render a single page's content — receives items + current page index */
  renderSlide: (items: SliderPage, pageIndex: number) => ReactNode;
  /**
   * Render-prop for controls.
   * Receives { ArrowPrev, ArrowNext, Dots } — pre-wired, zero-config.
   * If omitted, default controls render below the slide.
   */
  children?: (controls: ControlComponents) => ReactNode;
  /** Extra className on the viewport wrapper */
  className?: string;
  /** aria-label for the slider region */
  ariaLabel?: string;
}

// ── Component ───────────────────────────────────────────────────────────────

export function ImageSlider({
  slides,
  renderSlide,
  children,
  className,
  ariaLabel = 'Image slider',
}: ImageSliderProps) {
  const slideRef = useRef<HTMLDivElement>(null);
  const dirRef   = useRef<number>(1); // 1 = forward, -1 = backward

  // ── GSAP exit/enter ────────────────────────────────────────────────────
  const runExit = useCallback(
    (from: number, to: number): Promise<void> => {
      dirRef.current = to > from ? 1 : -1;
      return new Promise<void>((resolve) => {
        const el = slideRef.current;
        if (!el) { resolve(); return; }
        gsap.to(el, {
          opacity: 0,
          x: -36 * dirRef.current,
          duration: 0.3,
          ease: 'power2.in',
          onComplete: resolve,
        });
      });
    },
    [],
  );

  const { current, animating, goTo, prev, next } = useSlider({
    total: slides.length,
    onBeforeChange: runExit,
  });

  // ── Enter animation on slide change ────────────────────────────────────
  useEffect(() => {
    const el = slideRef.current;
    if (!el) return;
    gsap.fromTo(
      el,
      { opacity: 0, x: 36 * dirRef.current },
      { opacity: 1, x: 0, duration: 0.4, ease: 'power2.out' },
    );
  }, [current]);

  // ── Stagger child items on each new slide ──────────────────────────────
  useEffect(() => {
    const el = slideRef.current;
    if (!el) return;
    const items = el.querySelectorAll('[data-slider-item]');
    if (items.length === 0) return;
    gsap.fromTo(
      items,
      { opacity: 0, scale: 0.97, y: 12 },
      { opacity: 1, scale: 1, y: 0, duration: 0.55, stagger: 0.06, ease: 'power2.out' },
    );
  }, [current]);

  // ── Keyboard navigation ────────────────────────────────────────────────
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft')  prev();
      if (e.key === 'ArrowRight') next();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [prev, next]);

  // ── Pre-wired control components ───────────────────────────────────────
  const ArrowPrev = useCallback(
    () => (
      <button
        onClick={prev}
        disabled={animating}
        className={styles.slider__arrow}
        aria-label="前のスライド"
      >
        ←
      </button>
    ),
    [prev, animating],
  );

  const ArrowNext = useCallback(
    () => (
      <button
        onClick={next}
        disabled={animating}
        className={styles.slider__arrow}
        aria-label="次のスライド"
      >
        →
      </button>
    ),
    [next, animating],
  );

  const Dots = useCallback(
    () => (
      <div
        className={styles.slider__dots}
        role="tablist"
        aria-label="スライドナビゲーション"
      >
        {slides.map((_, i) => (
          <button
            key={i}
            role="tab"
            aria-selected={i === current}
            aria-label={`スライド ${i + 1}`}
            className={`${styles.slider__dot} ${i === current ? styles['slider__dot--active'] : ''}`}
            onClick={() => goTo(i)}
          />
        ))}
      </div>
    ),
    [slides, current, goTo],
  );

  const controls: ControlComponents = { ArrowPrev, ArrowNext, Dots };

  // ── Render ─────────────────────────────────────────────────────────────
  return (
    <div className={`${styles.slider} ${className ?? ''}`}>
      {/* Slide viewport */}
      <div className={styles.slider__viewport} aria-live="polite" aria-label={ariaLabel}>
        <div
          ref={slideRef}
          className={styles.slider__slide}
          aria-label={`スライド ${current + 1} / ${slides.length}`}
        >
          {renderSlide(slides[current], current)}
        </div>
      </div>

      {/* Controls — either via render prop or default layout */}
      {children
        ? children(controls)
        : (
          <>
            <div className={styles.slider__defaultArrows}>
              <ArrowPrev />
              <ArrowNext />
            </div>
            <Dots />
          </>
        )}
    </div>
  );
}
