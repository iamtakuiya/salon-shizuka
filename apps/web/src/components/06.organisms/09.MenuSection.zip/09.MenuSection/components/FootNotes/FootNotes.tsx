import styles from './FootNotes.module.scss';

interface FootNotesProps {
  notes: string[];
}

export const FootNote = ({ notes }: FootNotesProps ) => {
  return (
    <div className={styles.menu__footNotes}>
      {notes.map((note, i) => (
        <p key={i} className={styles.menu__footNote}>{note}</p>
      ))}
    </div>
  );
};