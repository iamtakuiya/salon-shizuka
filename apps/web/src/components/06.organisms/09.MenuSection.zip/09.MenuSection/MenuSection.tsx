import { useState, useEffect, useRef } from 'react';
import styles from './MenuSection.module.scss';
import { Section } from '@/components/01.primitives/Section/Section';
import { Container } from '@/components/01.primitives/Container/Container';
import { Stack } from '@/components/01.primitives/Stack/Stack';
import { MENU_CATEGORIES, MENU_FOOTER_NOTES } from '@/utils/constants';
import type { MenuCategory as ServiceMenuCategory } from '@/utils/services';
import { useMenuTabs } from '@/animations/hooks/useMenuTabs';
import { FootNote } from './components/FootNotes/FootNotes';
import { Divider } from '@/components/02.surface/05.Divider/Divider';
import { CategoryList } from './components/CategoryList/CategoryList';
import { Box } from '@/components/01.primitives/Box/Box';
import { MenuTabs } from './components/MenuTabs/MenuTabs';
import { MenuHeader } from './components/MenuHeader/MenuHeader';


// ─── MenuSection ─────────────────────────────────────────────────────────────
export default function MenuSection() {


  const [activeTabIdx, setActiveTabIdx] = useState(0);


  // Animated underline position — mirrors the submitted component's approach
  // Custom Hook invocation cleanly handles tab scrolling internals
  const { sliderStyle, tabsContainerRef, tabsRef } = useMenuTabs(activeTabIdx);

  // Split categories into two equal columns for the desktop layout
  const halfLength    = Math.ceil(MENU_CATEGORIES.length / 2);
  const leftColumn    = MENU_CATEGORIES.slice(0, halfLength);
  const rightColumn   = MENU_CATEGORIES.slice(halfLength);

  return (
    <Section
      id="menu"
      spacing="lg"
      aria-label="Menu &amp; Pricing"
      className={styles.menu}
    >
      <Container>
        <Stack gap="xl">

          {/* Section header */}
          <MenuHeader />

          {/* ── Tab strip — mobile only ─────────────────────────────────── */}
          {/* Hidden at ≥ 768 px via SCSS; aria-hidden keeps it out of the  */}
          {/* desktop accessibility tree.                                    */}
          <MenuTabs 
            categories={MENU_CATEGORIES}
            activeTab={activeTabIdx}
            setActiveTab={setActiveTabIdx}
            sliderStyle={sliderStyle}
            tabsRef={tabsRef}
            tabsContainerRef={tabsContainerRef}
          />

          {/* ── Category panels ─────────────────────────────────────────── */}
          <Box className={styles.menu__columns}>
            {/* Left column */}
            <Stack gap="lg" className={styles.menu__column}>
              <CategoryList menuList={leftColumn} activeTabIdx={activeTabIdx} />
            </Stack>

            {/* Vertical divider — desktop only */}
            <Divider orientation="vertical" className={['styles.divider--menu']} aria-hidden="true" />
            {/* <div className={styles.menu__divider} aria-hidden="true" /> */}

            {/* Right column */}
            <Stack gap="lg" className={styles.menu__column}>
              <CategoryList menuList={rightColumn} activeTabIdx={activeTabIdx} />
            </Stack>
          </Box>

          {/* Footer notes */}
          <FootNote notes={MENU_FOOTER_NOTES} />
        </Stack>
      </Container>
    </Section>
  );
}