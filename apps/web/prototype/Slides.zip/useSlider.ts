/**
 * useSlider
 * ─────────
 * Pure slider state + navigation logic.
 * No DOM, no GSAP — just the numbers and callbacks.
 * Consumed by <ImageSlider> and also directly by sections
 * that want full control over rendering.
 */

import { useState, useCallback } from 'react';

export interface UseSliderOptions {
  total: number;
  /** Called right before the index changes — lets the caller run an exit animation. */
  onBeforeChange?: (from: number, to: number) => Promise<void>;
  /** Called right after the index changes. */
  onAfterChange?: (index: number) => void;
}

export interface UseSliderReturn {
  current: number;
  animating: boolean;
  goTo: (index: number) => void;
  prev: () => void;
  next: () => void;
  canPrev: boolean;
  canNext: boolean;
}

export function useSlider({
  total,
  onBeforeChange,
  onAfterChange,
}: UseSliderOptions): UseSliderReturn {
  const [current,   setCurrent]   = useState(0);
  const [animating, setAnimating] = useState(false);

  const goTo = useCallback(
    async (next: number) => {
      if (animating || next === current || total <= 1) return;

      setAnimating(true);

      if (onBeforeChange) {
        await onBeforeChange(current, next);
      }

      setCurrent(next);
      setAnimating(false);
      onAfterChange?.(next);
    },
    [animating, current, total, onBeforeChange, onAfterChange],
  );

  const prev = useCallback(
    () => goTo((current - 1 + total) % total),
    [goTo, current, total],
  );

  const next = useCallback(
    () => goTo((current + 1) % total),
    [goTo, current, total],
  );

  return {
    current,
    animating,
    goTo,
    prev,
    next,
    canPrev: !animating && total > 1,
    canNext: !animating && total > 1,
  };
}
