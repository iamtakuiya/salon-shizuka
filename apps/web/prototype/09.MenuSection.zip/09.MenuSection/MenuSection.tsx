import { useState } from 'react';
import styles from './MenuSection.module.scss';
import { Section } from '@/components/01.primitives/Section/Section';
import { Container } from '@/components/01.primitives/Container/Container';
import { Stack } from '@/components/01.primitives/Stack/Stack';
import { useScrollReveal } from '@/animations/hooks/useScrollReveal';
import { SERVICES, ADDONS } from '@/utils/constants';

function formatPrice(yen: number) {
  return `¥${yen.toLocaleString('ja-JP')}`;
}

export default function MenuSection() {
  const labelRef   = useScrollReveal<HTMLSpanElement>();
  const headingRef = useScrollReveal<HTMLHeadingElement>();
  const [openTab, setOpenTab] = useState<'menu' | 'addon'>('menu');

  return (
    <Section
      id="menu"
      spacing="lg"
      aria-label="Menu &amp; Pricing"
      className={styles.menu}
    >
      <Container size="md">
        <Stack gap="xl">
          {/* Header */}
          <Stack gap="xs" align="center">
            <span ref={labelRef} className="section-label">Menu</span>
            <h2 ref={headingRef} className={styles.menu__heading}>
              メニュー・料金
            </h2>
          </Stack>

          {/* Tabs */}
          <div className={styles.menu__tabs} role="tablist">
            <button
              role="tab"
              aria-selected={openTab === 'menu'}
              className={`${styles.menu__tab} ${openTab === 'menu' ? styles['menu__tab--active'] : ''}`}
              onClick={() => setOpenTab('menu')}
            >
              メニュー
            </button>
            <button
              role="tab"
              aria-selected={openTab === 'addon'}
              className={`${styles.menu__tab} ${openTab === 'addon' ? styles['menu__tab--active'] : ''}`}
              onClick={() => setOpenTab('addon')}
            >
              オプション
            </button>
          </div>

          {/* Service list */}
          <div role="tabpanel" className={styles.menu__list}>
            {(openTab === 'menu' ? SERVICES : ADDONS).map((item, i) => (
              <div
                key={item.id}
                className={styles.menu__row}
                style={{ '--row-index': i } as React.CSSProperties}
              >
                <div className={styles.menu__rowLeft}>
                  <span className={styles.menu__rowName}>{item.nameJa}</span>
                  <span className={styles.menu__rowNameEn}>{item.name}</span>
                </div>
                <div className={styles.menu__rowRight}>
                  <span className={styles.menu__rowDuration}>{item.duration}</span>
                  <span className={styles.menu__rowPrice}>{formatPrice(item.price)}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Note */}
          <p className={styles.menu__note}>
            ※ 表示価格はすべて税込です。施術内容により価格が変動する場合がございます。
            詳しくはカウンセリング時にご確認ください。
          </p>
        </Stack>
      </Container>
    </Section>
  );
}
