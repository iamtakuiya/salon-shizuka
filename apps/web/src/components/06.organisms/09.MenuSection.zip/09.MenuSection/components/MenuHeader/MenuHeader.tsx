import { Stack } from "@/components/01.primitives/Stack/Stack";
import { useScrollReveal } from '@/animations/hooks/useScrollReveal';
import styles from './MenuHeader.module.scss';


export const MenuHeader = ({ }) => {
  const subHeadingRef   = useScrollReveal<HTMLParagraphElement>();
  const headingRef = useScrollReveal<HTMLHeadingElement>();

  return (
    <Stack gap="xs" align="center">
      <h2 ref={headingRef} className={styles.menu__heading}>
        Menu
      </h2>

      <p ref={subHeadingRef} className={styles.menu__subheading}>
        カウンセリングをもとに、あなたの骨格、髪質、<br />
        日々のライフスタイルに寄り添った施術をご提案いたします
      </p>
    </Stack>
  );
}
