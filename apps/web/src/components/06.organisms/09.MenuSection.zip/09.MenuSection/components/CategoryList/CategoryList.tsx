import styles from './CategoryList.module.scss';
import { CategoryCard } from '../CategoryCard/CategoryCard';
import type { MenuCategory } from '@/utils/constants';


interface CategoryListProps {
  menuList: MenuCategory[];
  activeTabIdx: number;
}

export function CategoryList({ menuList, activeTabIdx }:CategoryListProps ) {

  return (
    <>
      {/* Generic component, this is depends on the menuList (left or right)  */}
      {menuList.map((cat) => {
        const globalIdx = menuList.indexOf(cat);
        return (
          <div
            key={cat.id}
            id={`menu-panel-${cat.id}`}
            // Mobile: show only the active tab's panel
            className={`${styles.menu__panel} ${
              activeTabIdx === globalIdx
                ? styles['menu__panel--activeMobile']
                : styles['menu__panel--hiddenMobile']
            }`}
          >
            <CategoryCard category={cat} globalIndex={globalIdx} />
          </div>
        );
      })}
    </>
  );
};