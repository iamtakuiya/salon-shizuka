// import { Menu } from '@/utils/services';
// import { MenuItem } from './MenuItem';
// import styles from '../MenuSection.module.scss';

// interface Props {
//   category: Menu;
//   isActive: boolean;
//   categoryIndex: number;
// }

// export function MenuCategory({
//   category,
//   isActive,
//   categoryIndex,
// }: Props) {
//   return (
//     <article
//       className={`${styles.category} ${
//         isActive
//           ? styles.categoryActive
//           : styles.categoryHidden
//       }`}
//       role="tabpanel"
//       id={`panel-${categoryIndex}`}
//       aria-labelledby={`tab-${categoryIndex}`}
//     >
//       <header className={styles.categoryHeader}>
//         <h3 className={styles.categoryTitle}>
//           {category.category}
//         </h3>

//         <p className={styles.categoryDescription}>
//           {category.category_description}
//         </p>
//       </header>

//       {category.items.map((item) => (
//         <MenuItem
//           key={`${category.category}-${item.name}`}
//           item={item}
//         />
//       ))}

//       {category.notes && (
//         <div className={styles.categoryNote}>
//           <p>{category.notes}</p>
//         </div>
//       )}
//     </article>
//   );
// }